

public class Set {

    private static final String str = System.getProperty( "line.separator" );
        
    // Instance variable
    private Cashier[] set;

    // Constructor
    public Set( int nbr ) {
        //VOTRE CODE VIENT ICI
    }

    // Instance methods
    public void add (Client client) {
         //VOTRE CODE VIENT ICI
   }

    public void servedClients( int currentTime ) {
         //VOTRE CODE VIENT ICI
    }

    public String toString() {
        //VOTRE CODE VIENT ICI
    }
}
