/*************************Exemple2 Question d *********************/

public class TestBook {
   public static void main(String[] args) {
    Book book1 = new Book();
    book1.setAuthor("E.B.Koffman");
    System.out.println("Book of " + book1.getAuthor());
  }  
}