
/*************************Exercice1 Question b*********************/

public class TestBook {
   public static void main(String[] args) {
    Book book1 = new Book("E.B.Koffman ", "Abstraction and Design Using Java");
    Book book2 = new Book("Duane A.Bailey", " Data Structures in Java for Principled Programmer ");
    book2.affiche();
    System.out.println();
    System.out.println(book1);
  }  
}
 