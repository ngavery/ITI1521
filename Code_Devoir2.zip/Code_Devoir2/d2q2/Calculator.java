/**********************Q2-Devoir2 ITI1521*********/
class Calculator {
private double first, second; // two calculator operands
private String oP;  

Calculator() {};

void operation(String str) {
first = second; // keep first operand
second = 0; // initialize and get ready for second operand
oP = str;
}

void add() { operation("+"); }
void subtract() { 
//VOTRE CODE VIENT ICI 
}
void multiply() {
// VOTRE CODE VIENT ICI 
}
void divide() { 
//VOTRE CODE VIENT ICI 
}
void factorial() { 
//VOTRE CODE VIENT ICI 
} 
void pow() { 
//VOTRE CODE VIENT ICI
} 
void rootSquare() { 
//VOTRE CODE VIENT ICI 
} 
void nepLog() { 
//VOTRE CODE VIENT ICI 
} 


void compute() {
 
 //VOTRE CODE VIENT ICI
/*EXEMPLE : 
  if (oP == "+")
   second = first + second;
*/
 
 } 
  
void clear() {
//VOTRE CODE VIENT ICI
}

double display() {
//VOTRE CODE VIENT ICI
}

/*
AUTRES METHODES SI NECESSAIRE
*/

}





